plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.sahir.infinitywizard"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.sahir.infinitywizard"
        minSdk = 24
        targetSdk = 34
        versionCode = 7
        versionName = "1.5.0"
    }
    signingConfigs {
        getByName("debug") {
            storeFile = file("sahir.keystore")
            storePassword = "sahir123"
            keyAlias = "sahir"
            keyPassword = "sahir123"
        }
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("androidx.core:core-ktx:1.13.1")
}
